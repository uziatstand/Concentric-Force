----

CONTROLS:
A/D - left/right

SPACE - jump, you can double jump and jump off walls
Stay on a wall to slide down at a slower speed

LEFT CLICK - fire

Shoot the bird to gain points. Shoot it in quick succession
to gain points faster! Break its shield and take its life
to gain big bonuses to your score.

----

The Extras folder is other things about the development 
of the game.

The Art folder documents pieces I had made as
concept art/future assets.

The Stress Testing 2 videos are videos meant to illustrate
the second stress test in my input/output table - namely,
the test about hacking in an impossibly high score and
seeing what happens.
These were made in a modified version of the game,
where all score-related values were cranked up absurdly high
amounts and the bird's shields were made to cool down
instantly the moment it took damage, effectively making
it immortal. This made it easier to stack score off
shooting the bird without having to wait 7 seconds every
4 hits.

----